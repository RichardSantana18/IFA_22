﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista2Ex13
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Triangulo formato;
            formato = new Triangulo();

            Console.Write("Informe o primeiro valor: ");
            formato.setN1(int.Parse(Console.ReadLine()));

            Console.Write("Informe o segundo valor: ");
            formato.setN2(int.Parse(Console.ReadLine()));

            Console.Write("Informe o terceiro valor: ");
            formato.setN3(int.Parse(Console.ReadLine()));

            formato.calcular();
            Console.WriteLine("{0}", formato.getClassificacao());
        }
    }
}
