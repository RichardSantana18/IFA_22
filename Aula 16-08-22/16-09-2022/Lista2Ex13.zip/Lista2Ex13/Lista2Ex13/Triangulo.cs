﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista2Ex13
{
    internal class Triangulo
    {
        private double n1;
        private double n2;
        private double n3;
        private string clas;

        public Triangulo()
        {
            this.n1 = 0;
            this.n2 = 0;
            this.n3 = 0;
        }

        public Triangulo(double n1, double n2, double n3)
        {
            this.n1 = 0;
            this.n2 = 0;
            this.n3 = 0;
        }

        public void setN1(double n1)
        {
            this.n1 = n1;
        }
        public void setN2(double n2)
        {
            this.n2 = n2;
        }
        public void setN3(double n3)
        {
            this.n3 = n3;
        }

        public double getN1()
        {
            return this.n1;
        }
        public double getN2()
        {
            return this.n2;
        }
        public double getN3()
        {
            return this.n3;
        }
        public string getClassificacao()
        {
            return this.clas;
        }
        public void calcular()
        {
            this.n1 = Math.Pow(this.n1, 2);
            this.n2 = Math.Pow(this.n2, 2);
            this.n3 = Math.Pow(this.n3, 2);

            if ((this.n1 + this.n2) == this.n3)
            {
                this.clas = "Formam um Triângulo Retângulo";
            }
            else
            {
                if ((this.n3 + this.n2) == this.n1)
                {
                    this.clas = "Formam um Triângulo Retângulo";
                }
                else
                {
                    if ((this.n1 + this.n3) == this.n2)
                    {
                        this.clas = "Formam um Triângulo Retângulo";
                    }
                    else
                    {
                        this.clas = "Não Formam um Triângulo Retângulo";
                    }
                }
            }
        }
    }
}

